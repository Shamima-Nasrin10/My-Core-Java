
package jee59storeswing;


public class JEE59StoreSwing {

    public static void main(String[] args) {
       
    }
    
}
